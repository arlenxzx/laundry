<?php
$host = "localhost";
$usn = "root";
$pw = "";
$db = "laundry";
$con = mysqli_connect($host, $usn, $pw, $db);
?>
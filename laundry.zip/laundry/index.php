<?php 
header("Location: master/pages/index.php")
?>
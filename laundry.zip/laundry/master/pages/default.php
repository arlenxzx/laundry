<?php 
echo "<h6 class='mt-3'>Selamat datang " . $_SESSION['login'] . ", Silahkan pilih data untuk dikelola di tab sebelah kiri</h6>";
?>